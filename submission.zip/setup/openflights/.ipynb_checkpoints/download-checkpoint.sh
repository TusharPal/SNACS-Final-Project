wget -i raw_data_urls.txt -P ../../data/openflights -w 2
cd ../../data/openflights/
tar -xzvf inf-openflights.zip