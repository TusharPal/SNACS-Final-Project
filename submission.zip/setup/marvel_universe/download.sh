wget -i raw_data_urls.txt -P ../../data/marvel_universe -w 2
cd ../../data/marvel_universe
unzip marvel_universe.csv.zip