wget -i raw_data_urls.txt -P ../../data/us_roads_CT/ -w 2
cd ../../data/us_roads_CT/
unzip CT.csv.zip