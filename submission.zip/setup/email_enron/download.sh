wget -i raw_data_urls.txt -P ../../data/email_enron -w 2
cd ../../data/email_enron/
unzip email_enron.csv.zip