wget -i raw_data_urls.txt -P ../../data/rt-retweet-crawl -w 2
cd ../../data/rt-retweet-crawl
unzip rt-retweet-crawl.zip