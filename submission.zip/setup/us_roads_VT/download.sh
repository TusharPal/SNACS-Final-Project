wget -i raw_data_urls.txt -P ../../data/us_roads_VT/ -w 2
cd ../../data/us_roads_VT/
unzip VT.csv.zip