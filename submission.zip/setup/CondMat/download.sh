wget -i raw_data_urls.txt -P ../../data/CondMat -w 2
gzip -dv ../../data/CondMat/ca-CondMat.txt.gz