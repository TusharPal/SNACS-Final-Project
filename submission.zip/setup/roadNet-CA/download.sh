wget -i raw_data_urls.txt -P ../../data/roadNet-CA/ -w 2
gzip -dv ../../data/roadNet-CA/roadNet-CA.txt.gz