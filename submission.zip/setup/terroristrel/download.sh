wget -i raw_data_urls.txt -P ../../data/terroristrel 2
cd ../../data/terroristrel
unzip TerroristRel.zip