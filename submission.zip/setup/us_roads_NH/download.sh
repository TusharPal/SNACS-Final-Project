wget -i raw_data_urls.txt -P ../../data/us_roads_NH/ -w 2
cd ../../data/us_roads_NH/
unzip NH.csv.zip