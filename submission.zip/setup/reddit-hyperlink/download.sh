wget -i raw_data_urls.txt -P ../../data/reddit-hyperlink/ -w 2
