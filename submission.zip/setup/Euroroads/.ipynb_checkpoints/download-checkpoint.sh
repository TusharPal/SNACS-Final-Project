wget -i raw_data_urls.txt -P ../../data/Euroroads -w 2
cd ../../data/Euroroads/
tar -xzvf download.tsv.subelj_euroroad.tar.bz2 