wget -i raw_data_urls.txt -P ../../data/AstroPh -w 2
gzip -dkv ../../data/AstroPh/ca-AstroPh.txt.gz