wget -i raw_data_urls.txt -P ../../data/AstroPh -w 2
gzip -dv ../../data/AstroPh/ca-AstroPh.txt.gz