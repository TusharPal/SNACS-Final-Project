wget -i raw_data_urls.txt -P ../../data/digg_reply -w 2
cd ../../data/digg_reply/
unzip digg_reply.csv.zip